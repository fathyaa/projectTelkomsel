//
//  StructPaket.swift
//  projectTelkomsel
//
//  Created by Phincon on 16/02/23.
//

import Foundation

struct StructPaket {
    var jumlahKuota: String = ""
    var namaKuota: String = ""
    var hargaSebelum: String = ""
    var harga: String = ""
}
