//
//  ViewController+UITableView.swift
//  projectTelkomsel
//
//  Created by Phincon on 16/02/23.
//

import Foundation
import UIKit

extension ViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: TableViewCell.identifier, for: indexPath) as? TableViewCell else {return UITableViewCell() }
                
        cell.setupComponents()
        
        cell.setText(harga:"Rp\(harga[indexPath.row])", namaKuota: namaKuota[indexPath.row] , jumlahKuota:  "\(jumlahKuota[indexPath.row]) GB")
        cell.saveImage.image = UIImage(named: "save")
        cell.masaAktifImage.image = UIImage(named: "masaAktif")
        cell.selectionStyle = .none
        
        let attributeString: NSMutableAttributedString = NSMutableAttributedString(string: "Rp\(hargaSebelum[indexPath.row])")
            attributeString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: 2, range: NSRange(location: 0, length: attributeString.length))
        cell.hargaSebelumLabel.attributedText = attributeString
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return namaKuotaCount()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let title = "\(namaKuota[indexPath.row])"
        let message = "\(jumlahKuota[indexPath.row]) GB harganya Rp\(harga[indexPath.row])"
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Beli", style: .default))
        present(alert, animated: true)
    }
    
}
